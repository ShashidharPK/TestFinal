package com.accenture.apigee.model;

import java.util.ArrayList;

public class InputValidation {

	private static InputValidation InputValidation;
	private PolicyModelClass regularExpressionModule;
	private PolicyModelClass concurrentRatelimitingModule;
	private PolicyModelClass jsonThreatProtectionModule;
	private PolicyModelClass spikeArrestModule;
	private PolicyModelClass xmlThreatprotectionModule;
	private PolicyModelClass quataModule;
	private ArrayList<PolicyModelClass> policyModuleList;

	public ArrayList<PolicyModelClass> getPolicyModuleList() {
		if (policyModuleList == null) {
			policyModuleList = new ArrayList<PolicyModelClass>();
		}
		return policyModuleList;
	}

	public void setPolicyModuleList(ArrayList<PolicyModelClass> policyModuleList) {
		this.policyModuleList = policyModuleList;
	}

	public PolicyModelClass getRegularExpressionModule() {
		return regularExpressionModule;
	}

	public void setRegularExpressionModule(PolicyModelClass regularExpressionModule) {
		this.regularExpressionModule = regularExpressionModule;
	}

	public PolicyModelClass getConcurrentRatelimitingModule() {
		return concurrentRatelimitingModule;
	}

	public void setConcurrentRatelimitingModule(PolicyModelClass concurrentRatelimitingModule) {
		this.concurrentRatelimitingModule = concurrentRatelimitingModule;
	}

	public PolicyModelClass getJsonThreatProtectionModule() {
		return jsonThreatProtectionModule;
	}

	public void setJsonThreatProtectionModule(PolicyModelClass jsonThreatProtectionModule) {
		this.jsonThreatProtectionModule = jsonThreatProtectionModule;
	}

	public PolicyModelClass getSpikeArrestModule() {
		return spikeArrestModule;
	}

	public void setSpikeArrestModule(PolicyModelClass spikeArrestModule) {
		this.spikeArrestModule = spikeArrestModule;
	}

	public PolicyModelClass getXmlThreatprotectionModule() {
		return xmlThreatprotectionModule;
	}

	public void setXmlThreatprotectionModule(PolicyModelClass xmlThreatprotectionModule) {
		this.xmlThreatprotectionModule = xmlThreatprotectionModule;
	}

	public PolicyModelClass getQuataModule() {
		return quataModule;
	}

	public void setQuataModule(PolicyModelClass quataModule) {
		this.quataModule = quataModule;
	}

	public static InputValidation getInputValidation() {
		if (InputValidation == null) {
			InputValidation = new InputValidation();
		}
		return InputValidation;
	}
	
	public static InputValidation getInputValidation(boolean reset) {
		if (InputValidation == null || reset) {
			InputValidation = new InputValidation();
		}
		return InputValidation;
	}

}
