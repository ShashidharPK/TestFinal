var app = angular.module('app', ['ngRoute','ngResource','ngJSONPath']);
app.config(function($routeProvider){
    $routeProvider
        .when('/users',{
            templateUrl: '/views/users.html',
            controller: 'usersController'
        })
        .when('/roles',{
            templateUrl: '/views/roles.html',
            controller: 'rolesController'
        })
        .when('/finalJsonView',{
            templateUrl: '/views/finalJsonView.html'
           
        })
        .otherwise(
            { redirectTo: '/'}
        );
});


