package com.accenture.apigee.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Random;
import java.util.zip.ZipOutputStream;
import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.xml.sax.SAXException;

import com.accenture.apigee.main.CodeAnalysis;

@Controller
public class FileUploadController {
	@Autowired
	private CodeAnalysis codeAnalysis;

	@Autowired
	private UploadController uploadController;
	private String directoryURLVerified = "";

	@Value("${UPLOADED_FOLDER}")
	private String tempDirPath;

	private String destination;

	/**
	 * @param req
	 * @param res
	 * @return
	 * @throws GitAPIException 
	 * @throws TransportException 
	 * @throws InvalidRemoteException 
	 */
	//@PostMapping("/gitUrl.html")
	@RequestMapping("/gitUrl.html") 
	public ResponseEntity insert(@RequestParam(value = "gitUrl") String gitUrl,  
			   @RequestParam(value = "username") String userName,  
			   @RequestParam(value = "password") String pw) throws InvalidRemoteException, TransportException, GitAPIException {
		System.out.println("FileUploadController.insert()");
		String repoUrl = gitUrl;
		String username = userName;
		String password = pw;
		System.out.println("FileUploadController.insert()" +"repoUrl"+ repoUrl+"username"+username+"password"+password);
		String tempDirectoryPath=System.getProperty(tempDirPath);
		Random random=new Random();
		//String finalDirectoryPath=tempDirectoryPath+"API"+random.nextInt();
         String finalDirectoryPath="C:\\Users\\umang.kumar\\AppData\\Local\\Temp\\api-116966820";
		
		try {
			//With username and Password
			/*CloneCommand cloneCommand = Git.cloneRepository();
			cloneCommand.setURI(repoUrl);
			cloneCommand.setDirectory(Paths.get(finalDirectoryPath).toFile());
			cloneCommand.setCredentialsProvider(new UsernamePasswordCredentialsProvider("username", "password"));
			cloneCommand.call();*/
			System.out.println("Completed Cloning with credential"+"repoUrl"+repoUrl+"username"+username+"password"+password);

		 
		     //Without Credentials
		/*	if(repoUrl!=null) {
			System.out.println("Cloning " + repoUrl + " into " + repoUrl);
			Git.cloneRepository().setURI(repoUrl).setDirectory(Paths.get(finalDirectoryPath).toFile()).call();
			}*/
			System.out.println("Completed Cloning");
			directoryURLVerified = uploadController.findDir(new File(finalDirectoryPath + "/"), "apiproxy");
			if (directoryURLVerified != null) {
				String resultString = null;
				try {
					resultString = codeAnalysis.listFiles(directoryURLVerified);
					System.out.println(resultString);
				} catch (ParserConfigurationException | SAXException | IOException e) {
					return new ResponseEntity("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
				}

				return new ResponseEntity(resultString, HttpStatus.OK);

				// return new ModelAndView("finalJsonView", "message", resultString);
			} else {
				return new ResponseEntity("", HttpStatus.NOT_FOUND);
			}
		} finally {
			System.out.println("FileUploadController.insert()");
		}
	}
}
