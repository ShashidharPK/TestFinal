package com.accenture.apigee.model;

public class CodeAnaysisReport {

	private AuthenticationAutherization AuthenticationAutherization;

	private InputValidation InputValidation;

	private LoggingAuditing LoggingAuditing;

	public LoggingAuditing getLoggingAuditing() {

		if (LoggingAuditing == null) {
			LoggingAuditing = com.accenture.apigee.model.LoggingAuditing.getLoggingAuditing();
		}
		return LoggingAuditing;
	}
	
	public LoggingAuditing getLoggingAuditing(boolean reset) {

		if (LoggingAuditing == null || reset) {
			LoggingAuditing = com.accenture.apigee.model.LoggingAuditing.getLoggingAuditing(reset);
		}
		return LoggingAuditing;
	}

	public void setLoggingAuditing(LoggingAuditing loggingAuditing) {
		LoggingAuditing = loggingAuditing;
	}

	public InputValidation getInputValidation() {

		if (InputValidation == null) {
			setInputValidation(com.accenture.apigee.model.InputValidation.getInputValidation());
		}
		return InputValidation;
	}
	
	public InputValidation getInputValidation(boolean reset) {

		if (InputValidation == null  || reset) {
			setInputValidation(com.accenture.apigee.model.InputValidation.getInputValidation(reset));
		}
		return InputValidation;
	}

	public void setInputValidation(InputValidation inputValidation) {
		InputValidation = inputValidation;
	}

	public void setAuthenticationAutherization(AuthenticationAutherization authenticationAutherization) {
		AuthenticationAutherization = authenticationAutherization;
	}

	public AuthenticationAutherization getAuthenticationAutherization() {

		if (AuthenticationAutherization == null) {
			setAuthenticationAutherization(
					com.accenture.apigee.model.AuthenticationAutherization.getAuthenticationAutherization());
		}

		return AuthenticationAutherization;
	}
	
	public AuthenticationAutherization getAuthenticationAutherization(boolean reset) {

		if (AuthenticationAutherization == null || reset) {
			setAuthenticationAutherization(
					com.accenture.apigee.model.AuthenticationAutherization.getAuthenticationAutherization(reset));
		}

		return AuthenticationAutherization;
	}

	private static CodeAnaysisReport codeAnaysisReport = null;
	
	public static CodeAnaysisReport getCodeAnaysisReport(boolean reset) {
		if (codeAnaysisReport == null || reset) {
			codeAnaysisReport = new CodeAnaysisReport();
		}
		return codeAnaysisReport;
	}

	public static CodeAnaysisReport getCodeAnaysisReport() {
		if (codeAnaysisReport == null) {
			codeAnaysisReport = new CodeAnaysisReport();
		}
		return codeAnaysisReport;
	}

	

}
