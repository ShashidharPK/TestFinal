package com.accenture.apigee.model;

import java.util.ArrayList;

public class LoggingAuditing {

	private static LoggingAuditing LoggingAuditing;
	private PolicyModelClass messageLoggingModule;
	private ArrayList<PolicyModelClass> policyModuleList;

	public ArrayList<PolicyModelClass> getPolicyModuleList() {
		if (policyModuleList == null) {
			policyModuleList = new ArrayList<PolicyModelClass>();
		}
		return policyModuleList;
	}

	public void setPolicyModuleList(ArrayList<PolicyModelClass> policyModuleList) {
		this.policyModuleList = policyModuleList;
	}

	public PolicyModelClass getMessageLoggingModule() {
		return messageLoggingModule;
	}

	public void setMessageLoggingModule(PolicyModelClass messageLoggingModule) {
		this.messageLoggingModule = messageLoggingModule;
	}

	public static LoggingAuditing getLoggingAuditing() {
		if (LoggingAuditing == null) {
			LoggingAuditing = new LoggingAuditing();
		}
		return LoggingAuditing;
	}
	
	public static LoggingAuditing getLoggingAuditing(boolean reset) {
		if (LoggingAuditing == null || reset) {
			LoggingAuditing = new LoggingAuditing();
		}
		return LoggingAuditing;
	}

}
