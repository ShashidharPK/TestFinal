package com.accenture.apigee.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.xml.sax.SAXException;

import com.accenture.apigee.main.CodeAnalysis;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

@Controller
@PropertySource("classpath:application.properties")
public class UploadController {

	@Value("${UPLOADED_FOLDER}")
	private String tempDirPath;

	private String destination;

	@Autowired
	private CodeAnalysis codeAnalysis;

	private String finalDirectoryURL = "";
	private String directoryURLVerified = "";

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String homepage() {
		return "index";
	}
	
	@PostMapping("/upload")
	public ResponseEntity singleFileUpload(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
		System.out.println("UploadController.singleFileUpload() in Upload Controller");

	//public ResponseEntity<?> singleFileUpload(@RequestParam("extraField") String extraField, @RequestParam("files") MultipartFile file,
	//		RedirectAttributes redirectAttributes) {

		destination = System.getProperty(tempDirPath);
		/*
		 * if (file.isEmpty()) { redirectAttributes.addFlashAttribute("message",
		 * "Please select a file to upload"); return "redirect:index"; }
		 * 
		 * if (!getFileExtension(file.getOriginalFilename())) {
		 * redirectAttributes.addFlashAttribute("message",
		 * "Please upload file having extensions .zip only."); return "redirect:index";
		 * }
		 */

		try {

			/**
			 * save file to temp
			 */
			File zip = File.createTempFile(UUID.randomUUID().toString(), "temp");
			FileOutputStream o = new FileOutputStream(zip);
			IOUtils.copy(file.getInputStream(), o);
			o.close();

			try {
				ZipFile zipFile = new ZipFile(zip);
				Random rnd = new Random();
				String pathForExtraction = destination
						+ file.getOriginalFilename().substring(0, file.getOriginalFilename().indexOf("."))+ rnd.nextInt();
				zipFile.extractAll(pathForExtraction);
				finalDirectoryURL =pathForExtraction;
			} catch (ZipException e) {
				e.printStackTrace();
			} finally {
				/**
				 * delete temp file
				 */
				zip.delete();
			}

			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded '" + file.getOriginalFilename() + "'");

		} catch (IOException e) {
			e.printStackTrace();
		}

		// return "redirect:/uploadStatus";
		directoryURLVerified = findDir(new File(finalDirectoryURL + "/"), "apiproxy");

		if (directoryURLVerified != null) {
			String resultString = null;
			try {
				resultString = codeAnalysis.listFiles(directoryURLVerified);
				System.out.println(resultString);
			} catch (ParserConfigurationException | SAXException | IOException e) {
				return new ResponseEntity("Successfully uploaded - " + "", HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity(resultString, HttpStatus.OK);

			// return new ModelAndView("finalJsonView", "message", resultString);
		} else {
			return new ResponseEntity("", HttpStatus.NOT_FOUND);
		}
	}

/*	@GetMapping("/analyse")
	public ModelAndView analyseFiles() {
		directoryURLVerified = findDir(new File(finalDirectoryURL + "/"), "apiproxy");

		if (directoryURLVerified != null) {
			String resultString = codeAnalysis.listFiles(directoryURLVerified);
			System.out.println(resultString);
			return new ModelAndView("finalJsonView", "message", resultString);
		} else {
			return new ModelAndView("uploadStatus", "message", "Please upload A valid proxy");
		}

	}*/

	/*
	 * @GetMapping("/uploadStatus") public String uploadStatus() { return
	 * "uploadStatus"; }
	 */

	private boolean getFileExtension(String fullName) {
		System.out.println("UploadController.getFileExtension() in Upload Controller");

		if (fullName != null) {
			String fileName = new File(fullName).getName();
			int dotIndex = fileName.lastIndexOf('.');
			String ext = (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
			if (ext.equalsIgnoreCase("ZIP"))
				return true;
			else
				return false;
		}
		return false;
	}

	/**
	 * @param root
	 * @param name
	 * @return
	 */
	public String findDir(File root, String name) {
		System.out.println("UploadController.findDir() in Upload Controller");

		if (root.getName().equals(name)) {
			return root.getAbsolutePath();
		}

		File[] files = root.listFiles();

		if (files != null) {
			for (File f : files) {
				if (f.isDirectory()) {
					String myResult = findDir(f, name);
					if (myResult != null) {
						return myResult;
					}
				}
			}
		}

		return null;
	}
}