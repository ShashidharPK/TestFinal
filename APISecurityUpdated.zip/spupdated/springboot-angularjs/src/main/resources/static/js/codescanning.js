
app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.controller('usersController', function($scope) {
    $scope.headingTitle = "User List";
});

app.controller('codeScanningCtrl', ['$http','$scope', '$q', 'fileUpload','jsonPath', function($http,$scope, $q, fileUpload,jsonPath){
	 document.getElementById("loader").style.display = "none";
	
	    $scope.dataUpload = true;
	 	$scope.errVisibility = false;
	 	$scope.codeScanningResults ;
		$scope.authentication;
		$scope.inputvalidation;
		$scope.loggingAuditing;
	  	$scope.authenticationValue;
	  	$scope.loggingValue;
	    $scope.inputvalidationValue;
	    
	    $scope.clear = function() {
	    	$scope.codeScanningResults ="" ;
			$scope.authentication = "";
			$scope.inputvalidation ="";
			$scope.loggingAuditing = "";
		  	$scope.authenticationValue = "";
		  	$scope.loggingValue = "";
		    $scope.inputvalidationValue = "";
		    document.getElementById("uploadCaptureInputFile").value = "";		   
	    }
	   
	   // var me = $scope;
	    $scope.downloadVariable = function() {
	    	 var link = document.createElement("a");
	    	    link.download = "scanningreport.json";
	    	    var data = "text/json;charset=utf-8," + encodeURIComponent(JSON.stringify($scope.codeScanningResults ,null,'\t'));
	    	    link.href = "data:" + data;
	    	    link.click();
        };
        
        
        /*kanchan*/    
        $scope.downloadGitProject = function() { 
        	//alert("GitUrl......");
         var gitUrl = $('#gitUrl').val();  
         var username = $('#username').val();  
         var password = $('#password').val();  
         $http({
             method: "GET",
             url: "gitUrl.html",
             params:{"gitUrl" : gitUrl, "username": username, "password": password}
           }).then(function successCallback(response) {
                          var result = response.data;

            /*  console.log(abc);

					alert("Upload File"+result);
					$scope.errors = fileUpload
							.getResponse();
					// var jsonObj =
					// JSON.parse($scope.errors);
					console.log("Error"+JSON.stringify($scope.errors));*/
					
					$scope.codeScanningResults = result;
					$scope.authentication = result.AuthenticationAutherization.policyModuleList;
					//console.log("Authentication1"+JSON.stringify($scope.authentication));
					$scope.inputvalidation = result.InputValidation.policyModuleList;
					//console.log("inputvalidation1"+JSON.stringify($scope.inputvalidation));
					$scope.loggingAuditing = result.LoggingAuditing.policyModuleList;
					//console.log("inputvalidation1"+JSON.stringify($scope.loggingAuditing));
					$scope.authenticationWeight = 	parseInt($scope.authentication[0].weight) +
													parseInt($scope.authentication[1].weight) +
													parseInt($scope.authentication[2].weight) +
													parseInt($scope.authentication[3].weight) +
													parseInt($scope.authentication[4].weight) +
													parseInt($scope.authentication[5].weight) +
													parseInt($scope.authentication[6].weight);
					//console.log("authenticationWeight"+$scope.authenticationWeight);
					$scope.inputvalidationWeight = 	parseInt($scope.inputvalidation[0].weight) +
													parseInt($scope.inputvalidation[1].weight) +
													parseInt($scope.inputvalidation[2].weight) +
													parseInt($scope.inputvalidation[3].weight) +
													parseInt($scope.inputvalidation[4].weight) +
													parseInt($scope.inputvalidation[5].weight);
					//console.log("inputvalidationWeight"+$scope.inputvalidationWeight);
					$scope.loggingWeight = parseInt($scope.loggingAuditing[0].weight);
					//console.log("loggingWeight"+$scope.loggingWeight);
					if($scope.authenticationWeight >= 80) {
						$scope.authenticationValue = 80;
					}else if ($scope.authenticationWeight >= 60) {
						$scope.authenticationValue = 60;
					}else if($scope.authenticationWeight >= 20) {
						$scope.authenticationValue = 20;
					}else {
						$scope.authenticationValue = 5;
					}
					
					if($scope.inputvalidationWeight >= 80) {
						$scope.inputvalidationValue = 80;
					}else if ($scope.inputvalidationWeight >= 60) {
						$scope.inputvalidationValue = 60;
					}else if($scope.inputvalidationWeight >= 20) {
						$scope.inputvalidationValue = 20;
					}else {
						$scope.inputvalidationValue = 5;
					}
					
					if($scope.loggingWeight >= 50) {
						$scope.loggingValue = 20;
					} else {
						$scope.loggingValue = 5;
					}

					console.log($scope.authentication);
					console.log($scope.inputvalidation);
					console.log($scope.loggingAuditing);
			$scope.errVisibility = true;
			document
					.getElementById("loader").style.display = "none";
          },  
          function errorCallback(response) { 
				  document
					.getElementById("loader").style.display = "none";
				$scope.codeScanningResults ="" ;
				$scope.authentication = "";
				$scope.inputvalidation ="";
				$scope.loggingAuditing = "";
				$scope.authenticationValue = "";
				$scope.loggingValue = "";
				$scope.inputvalidationValue = "";
				document.getElementById("uploadCaptureInputFile").value = "";		  
				alert('Please select valid proxy bundle');  
          
         });  
        }  
  
  
	 $scope.uploadFile = function() {
								document.getElementById("loader").style.display = "block";
								var file = $scope.myFile;
								var uploadUrl = "/upload";
								fileUpload
										.uploadFileToUrl(file, uploadUrl)
										.then(
												function(result) {
													alert("Upload File"+result);
													$scope.errors = fileUpload
															.getResponse();
													// var jsonObj =
													// JSON.parse($scope.errors);

													
													$scope.codeScanningResults = $scope.errors;
													$scope.authentication = jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[*]");
													//console.log("Authentication"+$scope.authentication);
													$scope.inputvalidation = jsonPath(
															$scope.codeScanningResults,
															"$.InputValidation.policyModuleList[*]");
													//console.log("inputvalidation"+$scope.inputvalidation)
													$scope.loggingAuditing = jsonPath(
															$scope.codeScanningResults,
															"$.LoggingAuditing.policyModuleList[*]");
													//console.log("inputvalidation"+$scope.loggingAuditing);
													$scope.authenticationWeight = 	(parseInt(jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[0].weight"))) + parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[1].weight")))+parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[2].weight")))+parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[3].weight")))+parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[4].weight")))+parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[5].weight")))+parseInt((jsonPath(
															$scope.codeScanningResults,
															"$.AuthenticationAutherization.policyModuleList[6].weight")));
													//console.log("authenticationWeight"+JSON.stringify($scope.authenticationWeight));
													$scope.inputvalidationWeight = 	(parseInt(jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[0].weight"))) + parseInt((jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[1].weight")))+parseInt((jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[2].weight")))+parseInt((jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[3].weight")))+parseInt((jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[4].weight")))+parseInt((jsonPath(
																$scope.codeScanningResults,
																"$.InputValidation.policyModuleList[5].weight")));
													//console.log("inputvalidationWeight"+JSON.stringify($scope.inputvalidationWeight));
													$scope.loggingWeight = 	(parseInt(jsonPath(
															$scope.codeScanningResults,
															"$.LoggingAuditing.policyModuleList[0].weight"))) 
												//console.log("loggingWeight"+JSON.stringify($scope.loggingWeight));
													if($scope.authenticationWeight >= 80) {
														$scope.authenticationValue = 80;
													}else if ($scope.authenticationWeight >= 60) {
														$scope.authenticationValue = 60;
													}else if($scope.authenticationWeight >= 20) {
														$scope.authenticationValue = 20;
													}else {
														$scope.authenticationValue = 5;
													}
													
													if($scope.inputvalidationWeight >= 80) {
														$scope.inputvalidationValue = 80;
													}else if ($scope.inputvalidationWeight >= 60) {
														$scope.inputvalidationValue = 60;
													}else if($scope.inputvalidationWeight >= 20) {
														$scope.inputvalidationValue = 20;
													}else {
														$scope.inputvalidationValue = 5;
													}
													
													if($scope.loggingWeight >= 50) {
														$scope.loggingValue = 20;
													} else {
														$scope.loggingValue = 5;
													}
													
													
													
													console.log($scope.authentication);
													console.log($scope.inputvalidation);
													console.log($scope.loggingAuditing);
													$scope.errVisibility = true;
													document
															.getElementById("loader").style.display = "none";
												},
												function(error) {
													
													document
															.getElementById("loader").style.display = "none";
													$scope.codeScanningResults ="" ;
													$scope.authentication = "";
													$scope.inputvalidation ="";
													$scope.loggingAuditing = "";
												  	$scope.authenticationValue = "";
												  	$scope.loggingValue = "";
												    $scope.inputvalidationValue = "";
												    document.getElementById("uploadCaptureInputFile").value = "";		  
												    alert('Please select valid proxy bundle');
												})
							};
	 }]);





app.inject = ['jsonPath'];


app.service('fileUpload', ['$q','$http', function ($q,$http) {
	 var deffered = $q.defer();
	 var responseData;
	 this.uploadFileToUrl = function(file, uploadUrl){
	 var fd = new FormData();
	 fd.append('file', file);
	 return $http.post(uploadUrl, fd, {
	 transformRequest: angular.identity,
	 headers: { 'Content-Type' : undefined}
	 })
	 .success(function(response){
	/* $scope.errors = response.data.value; */
	 //  console.log(response);
	   responseData = response;
	   //alert(responseData+"responseData");
	   deffered.resolve(response);
	   return deffered.promise;
	   })
	   .error(function(error){
	   deffered.reject(error);
	   return deffered.promise;
	   });
	}
	this.getResponse = function() {
	 return responseData;
	 }
}]);


app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);






