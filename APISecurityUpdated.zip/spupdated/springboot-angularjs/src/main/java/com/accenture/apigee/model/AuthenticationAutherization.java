package com.accenture.apigee.model;

import java.util.ArrayList;

public class AuthenticationAutherization {

	private static AuthenticationAutherization AuthenticationAutherization;
	private PolicyModelClass TLSEnabled;
	private PolicyModelClass samlAssertion;
	private PolicyModelClass basicAuthentication;
	private PolicyModelClass jwtEnabled;
	private PolicyModelClass oauth2Policy;
	private PolicyModelClass oauth1Policy;
	private PolicyModelClass veryfyApiKey;
	private ArrayList<PolicyModelClass> policyModuleList;

	public PolicyModelClass getTLSEnabled() {
		return TLSEnabled;
	}

	public void setTLSEnabled(PolicyModelClass tLSEnabled) {
		TLSEnabled = tLSEnabled;
	}

	public PolicyModelClass getVeryfyApiKey() {
		return veryfyApiKey;
	}

	public void setVeryfyApiKey(PolicyModelClass veryfyApiKey) {
		this.veryfyApiKey = veryfyApiKey;
	}

	public ArrayList<PolicyModelClass> getPolicyModuleList() {
		if (policyModuleList == null) {
			policyModuleList = new ArrayList<PolicyModelClass>();
		}
		return policyModuleList;
	}

	public void setPolicyModuleList(ArrayList<PolicyModelClass> policyModuleList) {
		this.policyModuleList = policyModuleList;
	}

	public PolicyModelClass getSamlAssertion() {
		return samlAssertion;
	}

	public void setSamlAssertion(PolicyModelClass samlAssertion) {
		this.samlAssertion = samlAssertion;
	}

	public PolicyModelClass getBasicAuthentication() {
		return basicAuthentication;
	}

	public void setBasicAuthentication(PolicyModelClass basicAuthentication) {
		this.basicAuthentication = basicAuthentication;
	}

	public PolicyModelClass getJwtEnabled() {
		return jwtEnabled;
	}

	public void setJwtEnabled(PolicyModelClass jwtEnabled) {
		this.jwtEnabled = jwtEnabled;
	}

	public PolicyModelClass getOauth2Policy() {
		return oauth2Policy;
	}

	public void setOauth2Policy(PolicyModelClass oauth2Policy) {
		this.oauth2Policy = oauth2Policy;
	}

	public PolicyModelClass getOauth1Policy() {
		return oauth1Policy;
	}

	public void setOauth1Policy(PolicyModelClass oauth1Policy) {
		this.oauth1Policy = oauth1Policy;
	}

	public static void setAuthenticationAutherization(AuthenticationAutherization authenticationAutherization) {
		AuthenticationAutherization = authenticationAutherization;
	}

	public static AuthenticationAutherization getAuthenticationAutherization() {

		if (AuthenticationAutherization == null) {
			AuthenticationAutherization = new AuthenticationAutherization();

		}
		return AuthenticationAutherization;

	}
	
	public static AuthenticationAutherization getAuthenticationAutherization(boolean reset) {

		if (AuthenticationAutherization == null || reset) {
			AuthenticationAutherization = new AuthenticationAutherization();

		}
		return AuthenticationAutherization;

	}

}
