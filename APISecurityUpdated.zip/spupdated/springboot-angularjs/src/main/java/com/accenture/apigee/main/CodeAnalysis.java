package com.accenture.apigee.main;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.accenture.apigee.model.CodeAnaysisReport;
import com.accenture.apigee.util.CodeAnalysisUtility;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Component
public class CodeAnalysis {

	/**
	 * List all the files and folders from a directory
	 * 
	 * @param directoryName
	 *            to be listed
	 */
	public void listFilesAndFolders(String directoryName) {
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			System.out.println(file.getName());
		}
	}

	/**
	 * List all the files under a directory
	 * 
	 * @param directoryName
	 *            to be listed
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 */
	public String listFiles(String directoryName) throws ParserConfigurationException, SAXException, IOException {
		File directory = new File(directoryName);
		String jsonString = "";
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()) {
				DocumentBuilder dBuilder;
					dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
					Document doc = dBuilder.parse(file);
					doc.getDocumentElement().normalize();
					doc.getElementsByTagName("ProxyEndpoints");
					CodeAnaysisReport.getCodeAnaysisReport(true);
					CodeAnalysisUtility.getStaticCodeanalysisUtility(true).validatePolicies(directoryName, false);

					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					jsonString = gson.toJson(CodeAnaysisReport.getCodeAnaysisReport());
					System.out.println(gson.toJson(CodeAnaysisReport.getCodeAnaysisReport()));

				

			}

		}
		return jsonString;
	}

	/**
	 * List all the folder under a directory
	 * 
	 * @param directoryName
	 *            to be listed
	 */
	public void listFolders(String directoryName) {
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isDirectory()) {
				System.out.println(file.getName());
			}
		}
	}

	/**
	 * List all files from a directory and its subdirectories
	 * 
	 * @param directoryName
	 *            to be listed
	 */
	public void listFilesAndFilesSubDirectories(String directoryName) {
		File directory = new File(directoryName);
		// get all the files from a directory
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()) {
				System.out.println(file.getAbsolutePath());
			} else if (file.isDirectory()) {
				listFilesAndFilesSubDirectories(file.getAbsolutePath());
			}
		}
	}
}
