package com.accenture.apigee.util;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.accenture.apigee.model.CodeAnaysisReport;
import com.accenture.apigee.model.PolicyModelClass;

public class CodeAnalysisUtility {

	private static CodeAnalysisUtility staticCodeanalysisUtility = null;

	public CodeAnalysisUtility(boolean reset) {
		CodeAnaysisReport.getCodeAnaysisReport(reset);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization(reset);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation(reset);
		CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing(reset);

		setPolicyModuleforAuthentication();
		setPolicyModuleInputValidation();
		setLoggingAuditingModule();
	}
	
	public CodeAnalysisUtility() {
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization();
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation();
		CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing();

		setPolicyModuleforAuthentication();
		setPolicyModuleInputValidation();
		setLoggingAuditingModule();
	}

	public static CodeAnalysisUtility getStaticCodeanalysisUtility() {
		if (staticCodeanalysisUtility == null) {
			staticCodeanalysisUtility = new CodeAnalysisUtility();
		}
		return staticCodeanalysisUtility;
	}

	public static CodeAnalysisUtility getStaticCodeanalysisUtility(boolean reset) {
		if (staticCodeanalysisUtility == null || reset) {
			staticCodeanalysisUtility = new CodeAnalysisUtility(reset);
		}
		return staticCodeanalysisUtility;
	}

	public void validatePolicies(String directoryName, boolean isSharedFlow) throws ParserConfigurationException, SAXException, IOException {
        System.out.println("CodeAnalysisUtility.validatePolicies()");
		String defaultProxyFile = "";
		if (isSharedFlow) {

			defaultProxyFile = directoryName + "\\sharedflowbundle\\sharedflows" + "\\" + "default" + ".xml";
		} else {
			defaultProxyFile = directoryName + "\\proxies" + "\\" + "default" + ".xml";
		}

		File file = new File(defaultProxyFile);

		if (file.exists()) {

			DocumentBuilder dBuilder;
		

				dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document doc = dBuilder.parse(file);
				doc.getDocumentElement().normalize();
				NodeList nList;
				if (isSharedFlow) {
					nList = doc.getElementsByTagName("SharedFlow");
				} else {

					nList = doc.getElementsByTagName("PreFlow");
				}

				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);

					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						for (int count = 0; count < eElement.getElementsByTagName("Name").getLength(); count++) {

							String policyFile;
							if (isSharedFlow) {
								policyFile = directoryName + "\\sharedflowbundle\\policies" + "\\"
										+ eElement.getElementsByTagName("Name").item(count).getTextContent() + ".xml";
							} else {
								policyFile = directoryName + "\\policies" + "\\"
										+ eElement.getElementsByTagName("Name").item(count).getTextContent() + ".xml";
							}
							DocumentBuilder policyBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
							Document policyDoc = policyBuilder.parse(policyFile);
							policyDoc.getDocumentElement().normalize();

							if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("VerifyAPIKey")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getVeryfyApiKey().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
								.getVeryfyApiKey().setWeight(20);
							} else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("OAuthV2")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								for (int i = 0; i < policyDoc.getDocumentElement().getChildNodes().getLength(); i++) {
									if (policyDoc.getDocumentElement().getChildNodes().item(i).getNodeName()
											.equalsIgnoreCase("Operation")
											&& policyDoc.getDocumentElement().getChildNodes().item(i).getTextContent()
													.equalsIgnoreCase("VerifyAccessToken")) {

										CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
												.getOauth2Policy().setEnabled(true);
										CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getOauth2Policy().setWeight(80);
										break;
									}
								}
							} else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("OAuthV1")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								for (int i = 0; i < policyDoc.getDocumentElement().getChildNodes().getLength(); i++) {
									if (policyDoc.getDocumentElement().getChildNodes().item(i).getNodeName()
											.equalsIgnoreCase("Operation")
											&& policyDoc.getDocumentElement().getChildNodes().item(i).getTextContent()
													.equalsIgnoreCase("VerifyAccessToken")) {

										CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
												.getOauth1Policy().setEnabled(true);
										CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getOauth1Policy().setWeight(80);
										break;
									}
								}
							}

							else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("VerifyJWT")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getJwtEnabled().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
								.getJwtEnabled().setWeight(80);

							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("ValidateSAMLAssertion")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getSamlAssertion().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
								.getSamlAssertion().setWeight(40);
							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("BasicAuthentication")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getBasicAuthentication().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
								.getBasicAuthentication().setWeight(20);
							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("RegularExpressionProtection")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
										.getRegularExpressionModule().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getRegularExpressionModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("Quota")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {

								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getQuataModule()
										.setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getQuataModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("JSONThreatProtection")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
										.getJsonThreatProtectionModule().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getJsonThreatProtectionModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("SpikeArrest")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getSpikeArrestModule()
										.setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getSpikeArrestModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("XMLThreatProtection")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
										.getXmlThreatprotectionModule().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getXmlThreatprotectionModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName()
									.equalsIgnoreCase("ConcurrentRatelimit")
									&& ((policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true"))
											|| (policyDoc.getDocumentElement().getAttribute("enabled")
													.length() == 0))) {
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
										.getConcurrentRatelimitingModule().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
								.getConcurrentRatelimitingModule().setWeight(15);
							} else if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("FlowCallout")) {

								for (int i = 0; i < policyDoc.getDocumentElement().getChildNodes().getLength(); i++) {
									if (policyDoc.getDocumentElement().getChildNodes().item(i).getNodeName()
											.equalsIgnoreCase("SharedFlowBundle")) {
										String sharedFlow = policyDoc.getDocumentElement().getChildNodes().item(i)
												.getTextContent();
										String proxyFile = new File(directoryName).getParentFile().getAbsolutePath()
												+ "\\" + sharedFlow;
										System.out.println(
												"shared flow path here    ==========" + proxyFile + "\\" + sharedFlow);
										validatePolicies(proxyFile, true);
									}
								}
							}

						}

					}
				}

				nList = doc.getElementsByTagName("PostClientFlow");
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);

					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						for (int count = 0; count < eElement.getElementsByTagName("Name").getLength(); count++) {

							String policyFile = directoryName + "\\policies" + "\\"
									+ eElement.getElementsByTagName("Name").item(count).getTextContent() + ".xml";
							DocumentBuilder policyBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
							Document policyDoc = policyBuilder.parse(policyFile);
							policyDoc.getDocumentElement().normalize();

							if (policyDoc.getDocumentElement().getNodeName().equalsIgnoreCase("MessageLogging")
									&& policyDoc.getDocumentElement().getAttribute("enabled")
											.equalsIgnoreCase("true")) {
								CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing().getMessageLoggingModule()
										.setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing().getMessageLoggingModule().setWeight(50);

							}
						}
					}
				}

				nList = doc.getElementsByTagName("HTTPProxyConnection");
				for (int temp = 0; temp < nList.getLength(); temp++) {
					Node nNode = nList.item(temp);

					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						for (int count = 0; count < eElement.getElementsByTagName("VirtualHost").getLength(); count++) {
							if (eElement.getElementsByTagName("VirtualHost").item(count).getTextContent()
									.equalsIgnoreCase("secure")) {
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
										.getTLSEnabled().setEnabled(true);
								CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
								.getTLSEnabled().setWeight(20);
							}
						}

					}
				}

			
		} else {
			System.out.println("+++++++++++++++++++++++++++" + file.getAbsolutePath());
		}
	}

	private void setPolicyModuleInputValidation() {
		PolicyModelClass regularExpressionModule = new PolicyModelClass();
		regularExpressionModule.setPolicyName("RegularExpressionProtection");
		regularExpressionModule.setEnabled(false);
		regularExpressionModule.setWeight(1);
		regularExpressionModule
				.setComments("https://docs.apigee.com/api-services/reference/regular-expression-protection");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
				.setRegularExpressionModule(regularExpressionModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList()
				.add(regularExpressionModule);

		PolicyModelClass quataModule = new PolicyModelClass();
		quataModule.setPolicyName("Quota");
		quataModule.setEnabled(false);
		quataModule.setWeight(1);
		quataModule.setComments("https://docs.apigee.com/api-services/reference/quota-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().setQuataModule(quataModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList().add(quataModule);

		PolicyModelClass jsonThreatProtectionModule = new PolicyModelClass();
		jsonThreatProtectionModule.setPolicyName("JSONThreatProtection");
		jsonThreatProtectionModule.setEnabled(false);
		jsonThreatProtectionModule.setWeight(1);
		jsonThreatProtectionModule
				.setComments("https://docs.apigee.com/api-services/reference/json-threat-protection-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
				.setJsonThreatProtectionModule(jsonThreatProtectionModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList()
				.add(jsonThreatProtectionModule);

		PolicyModelClass spikeArrestModule = new PolicyModelClass();
		spikeArrestModule.setPolicyName("SpikeArrest");
		spikeArrestModule.setEnabled(false);
		spikeArrestModule.setWeight(1);
		spikeArrestModule.setComments("https://docs.apigee.com/api-services/reference/spike-arrest-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().setSpikeArrestModule(spikeArrestModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList().add(spikeArrestModule);

		PolicyModelClass xmlThreatProtectionModule = new PolicyModelClass();
		xmlThreatProtectionModule.setPolicyName("XMLThreatProtection");
		xmlThreatProtectionModule.setEnabled(false);
		xmlThreatProtectionModule.setWeight(1);
		xmlThreatProtectionModule
				.setComments("https://docs.apigee.com/api-services/reference/xml-threat-protection-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
				.setXmlThreatprotectionModule(xmlThreatProtectionModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList()
				.add(xmlThreatProtectionModule);

		PolicyModelClass concurrentRatelimitModule = new PolicyModelClass();
		concurrentRatelimitModule.setPolicyName("ConcurrentRatelimit");
		concurrentRatelimitModule.setEnabled(false);
		concurrentRatelimitModule.setWeight(1);
		concurrentRatelimitModule
				.setComments("https://docs.apigee.com/api-services/reference/concurrent-rate-limit-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation()
				.setConcurrentRatelimitingModule(concurrentRatelimitModule);
		CodeAnaysisReport.getCodeAnaysisReport().getInputValidation().getPolicyModuleList()
				.add(concurrentRatelimitModule);

	}

	private void setLoggingAuditingModule() {
		PolicyModelClass messageLoggingModule = new PolicyModelClass();
		messageLoggingModule.setPolicyName("MessageLogging");
		messageLoggingModule.setEnabled(false);
		messageLoggingModule.setWeight(1);
		messageLoggingModule
				.setComments("https://docs.apigee.com/api-services/reference/regular-expression-protection");
		CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing().setMessageLoggingModule(messageLoggingModule);
		CodeAnaysisReport.getCodeAnaysisReport().getLoggingAuditing().getPolicyModuleList().add(messageLoggingModule);
	}

	private void setPolicyModuleforAuthentication() {
		PolicyModelClass tlsEnabled = new PolicyModelClass();
		tlsEnabled.setPolicyName("TLSEnabled");
		tlsEnabled.setEnabled(false);
		tlsEnabled.setWeight(1);
		tlsEnabled.setComments("https://docs.apigee.com/api-services/content/ssl");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setTLSEnabled(tlsEnabled);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList().add(tlsEnabled);

		PolicyModelClass verifyApikeyModule = new PolicyModelClass();
		verifyApikeyModule.setPolicyName("VerifyAPIKey");
		verifyApikeyModule.setEnabled(false);
		verifyApikeyModule.setWeight(1);
		verifyApikeyModule.setComments("https://docs.apigee.com/api-services/reference/verify-api-key-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setVeryfyApiKey(verifyApikeyModule);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(verifyApikeyModule);

		PolicyModelClass oauth2Module = new PolicyModelClass();
		oauth2Module.setPolicyName("Oauth2");
		oauth2Module.setEnabled(false);
		oauth2Module.setWeight(1);
		oauth2Module.setComments("https://docs.apigee.com/api-services/content/oauth-introduction");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setOauth2Policy(oauth2Module);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(oauth2Module);

		PolicyModelClass oauth1Module = new PolicyModelClass();
		oauth1Module.setPolicyName("Oauth1");
		oauth1Module.setEnabled(false);
		oauth1Module.setWeight(1);
		oauth1Module.setComments("https://docs.apigee.com/api-services/reference/oauth-10-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setOauth1Policy(oauth1Module);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(oauth1Module);

		PolicyModelClass jwtEnabledModule = new PolicyModelClass();
		jwtEnabledModule.setPolicyName("VerifyJWT");
		jwtEnabledModule.setEnabled(false);
		jwtEnabledModule.setWeight(1);
		jwtEnabledModule.setComments("https://docs.apigee.com/api-services/reference/verify-jwt-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setJwtEnabled(jwtEnabledModule);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(jwtEnabledModule);

		PolicyModelClass samlAssertionModule = new PolicyModelClass();
		samlAssertionModule.setPolicyName("ValidateSAMLAssertion");
		samlAssertionModule.setEnabled(false);
		samlAssertionModule.setWeight(1);
		samlAssertionModule.setComments("https://docs.apigee.com/api-services/reference/saml-assertion-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().setSamlAssertion(samlAssertionModule);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(samlAssertionModule);

		PolicyModelClass basicAuthenticationModule = new PolicyModelClass();
		basicAuthenticationModule.setPolicyName("BasicAuthentication");
		basicAuthenticationModule.setEnabled(false);
		basicAuthenticationModule.setWeight(1);
		basicAuthenticationModule
				.setComments("https://docs.apigee.com/api-services/reference/basic-authentication-policy");
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization()
				.setBasicAuthentication(basicAuthenticationModule);
		CodeAnaysisReport.getCodeAnaysisReport().getAuthenticationAutherization().getPolicyModuleList()
				.add(basicAuthenticationModule);

	}
}
